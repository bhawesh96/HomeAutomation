<?php

$hall = readfile("hall.txt");
$room1 = readfile("room1.txt");
$room2 = readfile("room2.txt");
$string = $hall.$room1.$room2;
echo $string;
fclose("hall.txt");
fclose("room1.txt");
fclose("room2.txt");
$myfile = fopen("main.txt", "w") or die("Unable to open file!");
fwrite($myfile, $string);
fclose($myfile);
?>